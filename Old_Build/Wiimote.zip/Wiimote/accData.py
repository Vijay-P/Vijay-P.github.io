__author__ = 'root'

#!/usr/bin/env python

# test with
# sudo LD_LIBRARY_PATH=<prefix>/lib PYTHONPATH=<prefix>/lib/python2.7/site-packages python ./swig/python/xwiimote_test.py

import errno
import time
from time import sleep
from select import poll, POLLIN
from inspect import getmembers
from pprint import pprint
import xwiimote
from time import gmtime, strftime
from multiprocessing import Process, Queue
import turtle
import tkMessageBox as box
import tkSimpleDialog as sd
import Tkinter
import accData2

root = Tkinter.Tk()
root.withdraw()

file = open("newfile.txt", "w")

# display a constant
print "=== " + xwiimote.NAME_CORE + " ==="

# list wiimotes and remember the first one
try:
    mon = xwiimote.monitor(True, True)
    # print "mon fd", mon.get_fd(False)
    ent = mon.poll()
    firstwiimote = ent
    while ent is not None:
        print "Found device: " + ent
        ent = mon.poll()
except SystemError as e:
    print "ooops, cannot create monitor (", e, ")"

# continue only if there is a wiimote
if firstwiimote is None:
    print "No wiimote to read"
    exit(0)

# create a new iface
try:
    dev = xwiimote.iface(firstwiimote)
except IOError as e:
    print "ooops,", e
    exit(1)

# display some information and open the iface
try:
    # print "syspath:" + dev.get_syspath()
    fd = dev.get_fd()
    # print "fd:", fd
    # print "opened mask:", dev.opened()
    dev.open(dev.available() | xwiimote.IFACE_WRITABLE)
    # print "opened mask:", dev.opened()

    dev.rumble(True)
    sleep(1/4.0)
    dev.rumble(False)
    dev.set_led(1, dev.get_led(2))
    dev.set_led(2, dev.get_led(3))
    dev.set_led(3, dev.get_led(4))
    dev.set_led(4, dev.get_led(4) == False)
    print "capacity:",  dev.get_battery(), "%"
    # print "devtype:",   dev.get_devtype()
    # print "extension:", dev.get_extension()
except SystemError as e:
    print "ooops", e
    exit(1)

dev.open(xwiimote.IFACE_IR)
dev.close(xwiimote.IFACE_MOTION_PLUS)
dev.close(xwiimote.IFACE_ACCEL)
# print "opened mask:", dev.opened()

#
seconds = sd.askinteger("Gesture Reader", "How many seconds do you want to enable gesture entry for?", )
root.withdraw()
g = False

def clock1(q):
    # print "clocking"
    start = time.time()
    time.clock()
    elapsed = 0.0
    while elapsed < seconds:
        elapsed = time.time() - start
        # if elapsed.is_integer():
        #     print elapsed
    if elapsed >= seconds:
        # print "clocktime"
        # print q.qsize()
        g = False
        q.get()
        q.put(g)
        # print g

def peek():
    hold = q.get()
    q.put(hold)
    return hold

if __name__=='__main__':
    q = Queue()
    p1 = Process(target = clock1, args = (q,))
    q.put(g)

def visualizerset():
    wn = turtle.Screen()
    wn.title("Wiimote IR Data")
    wn.setup(width=1366, height=786, startx=None, starty=None)
    wn.setworldcoordinates(-1015,-760, -8, -10)

    wiimotedata = turtle.Turtle()
    wiimotedata.shape("circle")
    wiimotedata.speed(0)
    wiimotedata.penup()

    uiturtle = turtle.Turtle()
    uiturtle.shape("circle")
    uiturtle.color("blue")
    uiturtle.penup()
    uiturtle.speed(0)
    uiturtle.goto(-503, -17)
    uiturtle.stamp()
    uiturtle.goto(-503, -375)
    uiturtle.stamp()
    uiturtle.goto(-503, -733)
    uiturtle.stamp()
    uiturtle.goto(-985, -375)
    uiturtle.stamp()
    uiturtle.goto(-35, -373)
    uiturtle.stamp()

    return wiimotedata


def visualizer(turtlePrimary, flag1, x, y):
    turtlePrimary.penup()
    if(flag1 == 1):
        turtlePrimary.goto(-(x), -(y))
    else:
        turtlePrimary.goto(-(x), -(y))

wiimotedata = visualizerset()

startflag = False
p = poll()
p.register(fd, POLLIN)
evt = xwiimote.event()
n = True
times = 0;
times2 = 1;
while n == True:
    # print "running"
    try:
        p.poll()
        dev.dispatch(evt)
        # print "polling"
        if evt.type == xwiimote.EVENT_KEY:
            # print "event"
            code, state = evt.get_key()
            # print "Key:", code, ", State:", state
            if(code == 4 and state == 1):
                startflag = True
                g = True
                # print q.qsize()
                q.get()
                q.put(g)
        elif evt.type == xwiimote.EVENT_IR and peek() == True:
            if times == 0:
                p1.start()
                times+=1
            x, y, z = evt.get_abs(0)
            # coordinates = [x, y, z]
            if(x != 1023 and y != 1023):
                coordinates = [x, y]
            str1 = ','.join(str(e) for e in coordinates) + "\n"
            # print str1
            visualizer(wiimotedata, times2, x, y)
            file.write(str1)

        elif q.qsize()<1 and peek() != False:
            q.put(g)
            # print"cutting losses"
        elif peek() == False and startflag == True:
            # print "kill"
            n = False
    except IOError as e:
        if e.errno != errno.EAGAIN:
            print "Bad"

file.close()

def gestureRead():
    file = open('newfile.txt', 'r')
    firstrun = True
    combo = []
    for line in file:
        temp = line.split(",")
        temp[1] = temp[1].replace('\n', '')
        a = int(temp[0])
        b = int(temp[1])
        if(firstrun == True):
            initiala = a
            initialb = b
            firstrun = False
        if (firstrun == False):
            if (a-initiala) <= -400:
                combo.append("RIGHT")
                # print "Rignt"
                # print a, "-", initiala, "=", a-initiala, "<= -400"
                initiala = a
                initialb = b
                # print "new center: (", initiala, ",", initialb, ")"
            elif (a-initiala) >= 400:
                combo.append("LEFT")
                # print "Left"
                # print a, "-", initiala, "=", a-initiala, ">= 400"
                initiala = a
                initialb = b
                # print "new center: (", initiala, ",", initialb, ")"
            elif (b-initialb) <= -250:
                combo.append("UP")
                # print "Up"
                # print b, "-", initialb, "=", b-initialb, "<= -300"
                initialb = b
                initiala = a
                # print "new center: (", initiala, ",", initialb, ")"
            elif (b-initialb) >= 250:
                combo.append("DOWN")
                # print "Down"
                # print b, "-", initialb, "=", b-initialb, "<= 300"
                initialb = b
                initiala = a
                # print "new center: (", initiala, ",", initialb, ")"
    file.close()
    return "Your input combination was:", combo

box.showinfo("Gesture", gestureRead())
#box.showinfo("Gesture", accData2.script())

exit(0)

#If we were to complete this program:
#Immediate Goals:
#What we have programmed is the write function. We would use a similar algorithm to allow users to input gestures and
#compare the data with the lists yielded by gestureRead function. This data would be stored in a .txt file.
#program the up and down button on d pad to do numbers
#program trigger for enter
#Improve algorithm to curve fit data over a set of 3 data entries.
#If possible, poll for button presses while processing IR Data. Make this the event for start/stop.