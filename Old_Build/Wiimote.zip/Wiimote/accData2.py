def script():
    file = open('newfile.txt', 'r')
    firstrun = True
    combo = []
    for line in file:
        temp = line.split(",")
        temp[1] = temp[1].replace('\n', '')
        a = int(temp[0])
        b = int(temp[1])
        if(firstrun == True):
            initiala = a
            initialb = b
            firstrun = False
        if (firstrun == False):
            if (a-initiala) <= -400:
                combo.append("RIGHT")
                # print "Rignt"
                # print a, "-", initiala, "=", a-initiala, "<= -400"
                initiala = a
                initialb = b
                # print "new center: (", initiala, ",", initialb, ")"
            elif (a-initiala) >= 400:
                combo.append("LEFT")
                # print "Left"
                # print a, "-", initiala, "=", a-initiala, ">= 400"
                initiala = a
                initialb = b
                # print "new center: (", initiala, ",", initialb, ")"
            elif (b-initialb) <= -250:
                combo.append("UP")
                # print "Up"
                # print b, "-", initialb, "=", b-initialb, "<= -300"
                initialb = b
                initiala = a
                # print "new center: (", initiala, ",", initialb, ")"
            elif (b-initialb) >= 250:
                combo.append("DOWN")
                # print "Down"
                # print b, "-", initialb, "=", b-initialb, "<= 300"
                initialb = b
                initiala = a
                # print "new center: (", initiala, ",", initialb, ")"
    file.close()
    return "Your input combination was:", combo