from SimpleCV import*
import freenect
import numpy as np
import pygame
from Tkinter import Tk
import tkMessageBox as mb
from tkFileDialog import askopenfilename
import cv2

Tk().withdraw()
filename = askopenfilename(title = "Choose a background (minimum 640x480 widthxheight)")

cam = Kinect()

ctx = freenect.init()
num = freenect.num_devices(ctx)
dev = freenect.open_device(ctx, num-1)
freenect.set_tilt_degs(dev, 20)
freenect.close_device(dev)

def get_depth():
    array,_ = freenect.sync_get_depth()
    array = array.astype(np.uint8)
    # array = np.rot90(array, 1)
    # array = np.flipud(array)
    array = array[:,:-1]
    array = array.transpose(1,0)
    return array

def get_video():
    array,_ = freenect.sync_get_video()
    array = cv2.cvtColor(array,cv2.COLOR_RGB2BGR)
    array = array.transpose(1,0,2) #transpose rows and columns (image is sideways)
    array = array[:,:,::-1] #BGR to RBG
    return array

#We are using freenect libaraies because SimpleCV does not have a wrapper for sync_get_video.
#It only has a wrapper for get_video and get_depth.
mb.showinfo("Greenscreen","Press \"q\" to quit.")
while True:
    image = cam.getImage().scale(960,720)
    depth = cam.getDepth().scale(960,720)
    # image = Image(get_video()).scale(960,720)
    # depth = Image(get_depth()).scale(960,720)

    gs = Image(filename)
    if gs.width != 640 and gs.height != 480:
        greenscreen = gs.crop((gs.width/2)-(640/2),(gs.height/2)-(480/2),640,480).scale(960,720)

    # filtered2 = depth.stretch(40, 41)
    filtered2 = depth.stretch(210, 211)
    filtered = filtered2.binarize()

    result = (greenscreen - filtered) + (image - filtered.invert())

    result.show()

    #if q is pressed, break
    if(pygame.key.get_pressed()[pygame.K_q] !=0):
        break
