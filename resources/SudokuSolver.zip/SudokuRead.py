#Easy puzzle example (for short runtime):
#.1.53.87..24.975....5....9....1....9.4.6..2815...84.6.967..81....891...71....6...

import numpy as np
from math import ceil
from time import gmtime, strftime

# Create a sudoku board from a string.
# The sudoku board is a 9x9 numpy arroy of int8s.
def String2Sudoku(string):
	if (len(string) not in [81, 82]):
		return
	grid = np.zeros([9,9], np.int8)
	pos = 0
	for i in range(9):
		for j in range(9):
			if string[pos] == '.':
				grid[i,j] = 0
			else:
				grid[i,j] = int(string[pos])
			pos += 1
	return grid

def checkSolution(puzzle, row, col):
	def checkRow(puzzle, row):
		row-=1
		taken = []
		for i in puzzle[row]:
			if(i not in taken and i != 0):
				taken.append(i)
			else:
				if(i != 0):
					return False
		return True


	def checkCol(puzzle, col):
		col-=1
		taken = []
		for i in puzzle[:,col]:
			if(i not in taken and i != 0):
				taken.append(i)
			else:
				if(i != 0):
					return False
		return True

	def checkSquares(puzzle, row, col):
		square_col = (ceil(float(col)/3))*3
		square_row = (ceil(float(row)/3))*3
		square = puzzle[square_row-3:square_row, square_col-3:square_col].ravel()
		taken = []
		for i in square:
			if(i not in taken and i != 0):
				taken.append(i)
			else:
				if(i != 0):
					return False
		return True

	if(checkSquares(puzzle, row, col) == True and checkCol(puzzle, col) == True and checkRow(puzzle, row) == True):
		return True
	else:
		return False

def Solve(puzzle, row, col):
	if(row==9):
		print("\n" + "Solution:")
		print(format(puzzle))
		print(strftime("%Y-%m-%d %H:%M:%S", gmtime()))
		return
	if(grid[row, col] == 0):
		test = np.copy(puzzle)
		for k in range (1, 10):
			test[row, col] = k
			if (checkSolution(test, row+1, col+1)):
				puzzle[row, col] = k
				if(col<8):
					Solve(puzzle, row, col+1)
				elif(col==8):
					Solve(puzzle, row+1, 0)
				puzzle[row, col] = 0
	else:
		if(col<8):
			Solve(puzzle, row, col+1)
		elif(col==8):
			Solve(puzzle, row+1, 0)

def format(puzzle):
	formattedPuzzle = ""
	for row in range (0, len(puzzle)):
		if(row == 0 or row == 3 or row == 6):
			formattedPuzzle += "+-----+-----+-----+\n"
		for col in range (0, len(puzzle[row])):
			if(col == 0 or col == 3 or col == 6):
				formattedPuzzle += "|"
				temp = []
				for i in range (col, col+3):
					if(puzzle[row, i] == 0):
						temp.append("_")
					else:
						temp.append(puzzle[row, i])
				formattedPuzzle += "{0} {1} {2}".format(temp[0], temp[1], temp[2])
		formattedPuzzle += "|\n"
	formattedPuzzle += "+-----+-----+-----+\n"
	return formattedPuzzle

if __name__ == "__main__":
	print(strftime("%Y-%m-%d %H:%M:%S", gmtime()))
	filename = "HardSudoku95.txt"
	f = open(filename)
	for line in f:
		grid = String2Sudoku(line)
		print("\n" + "Unsolved Puzzle:")
		print(format(grid))
		break
	Solve(grid, 0, 0)

#Output @ incredibly long runtime:
# [Vijay@localhost Sudoku]$ python SudokuRead.py
# 2016-03-08 19:22:50
#
# Unsolved Puzzle:
# +-----+-----+-----+
# |4 _ _|_ _ _|8 _ 5|
# |_ 3 _|_ _ _|_ _ _|
# |_ _ _|7 _ _|_ _ _|
# +-----+-----+-----+
# |_ 2 _|_ _ _|_ 6 _|
# |_ _ _|_ 8 _|4 _ _|
# |_ _ _|_ 1 _|_ _ _|
# +-----+-----+-----+
# |_ _ _|6 _ 3|_ 7 _|
# |5 _ _|2 _ _|_ _ _|
# |1 _ 4|_ _ _|_ _ _|
# +-----+-----+-----+
#
#
# Solution:
# +-----+-----+-----+
# |4 1 7|3 6 9|8 2 5|
# |6 3 2|1 5 8|9 4 7|
# |9 5 8|7 2 4|3 1 6|
# +-----+-----+-----+
# |8 2 5|4 3 7|1 6 9|
# |7 9 1|5 8 6|4 3 2|
# |3 4 6|9 1 2|7 5 8|
# +-----+-----+-----+
# |2 8 9|6 4 3|5 7 1|
# |5 7 3|2 9 1|6 8 4|
# |1 6 4|8 7 5|2 9 3|
# +-----+-----+-----+
#
# 2016-03-08 20:09:46
