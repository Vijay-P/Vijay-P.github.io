# pyBFI

### Python3 BrainFuck Interpreter

- This interpreter does no optimizations.

- This implementation uses an individual byte for each cell and the values are taken modulo 256.

- This interpreter only accepts ".bf" files.

**Usage:**

`usage:  bfi.py [-h] [-v] filename`

*positional arguments:*

`filename:   file to interpret`

*optional arguments:*

`-h, --help:     show this help message and exit`

`-v --verbose:   verbose mode`

**This project is avaliable through git via:**
- SSH: `git@src-code.simons-rock.edu:vpillai13/pyBFI.git`
- HTTPS: `https://src-code.simons-rock.edu/git/vpillai13/pyBFI.git`
