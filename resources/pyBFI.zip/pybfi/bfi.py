#!/usr/bin/env python3

import argparse
import logging
import string

# global variables: options
verbose = False
# global variable: program
inputprogram = ""
# global variable: counters
bytecells = [0]
currentcell = 0
currentchar = 0
# global variable: program output
output = ""

# logging
log = {
    'format': '%(asctime)s - %(levelname)s %(message)s',
    'level': logging.DEBUG
}
logging.basicConfig(**log)
logging.info("Interpreter start.")

# argparse setup and argument checking
parser = argparse.ArgumentParser(description='A BrainFuck interpreter.')
parser.add_argument('-v', '--verbose', help='verbose mode', action="store_true")
parser.add_argument('filename', help='file to interpret')
args = parser.parse_args()
if(args.filename[-3:] != ".bf"):
    logging.error("Invalid file type.")
    exit(0)
if(args.verbose):
    verbose = True
    logging.info("Verbose mode enabled.")

filename = args.filename
f = open(filename, 'r')
inputprogram = f.read()


# check braces to see if program is valid


def validity_check():
    global inputprogram
    stack = []
    for character in inputprogram:
        if(character == '['):
            stack.append(character)
        elif(character == ']'):
            if(len(stack) > 0):
                stack.pop()
            else:
                logging.error("Program invalid.")
                exit(0)
    if(len(stack) != 0):
        logging.error("Program invalid.")
        exit(0)


# functions for BrainFuck commands

#+
def plus():
    global bytecells
    global currentcell
    global currentchar
    bytecells[currentcell] = (bytecells[currentcell] + 1) % 256
    currentchar += 1

#-


def minus():
    global bytecells
    global currentcell
    global currentchar
    bytecells[currentcell] = (bytecells[currentcell] - 1) % 256
    currentchar += 1

#>


def right():
    global bytecells
    global currentcell
    global currentchar
    nex = currentcell + 1
    if(nex > len(bytecells) - 1):
        bytecells.append(0)
    currentcell = nex
    currentchar += 1

#<


def left():
    global currentcell
    global currentchar
    nex = currentcell - 1
    if(nex < 0):
        logging.error("Pointer out of bounds:" + str(nex))
        exit(0)
    else:
        currentcell = nex
    currentchar += 1

# helper for rbracket()


def find_matching_lbracket(index):
    global inputprogram
    ldex = 0
    rdex = index - 1
    while(True):
        previous_l = inputprogram.rfind("[", ldex, rdex)
        matching_r = inputprogram.find("]", previous_l, rdex)
        if(matching_r == -1):
            return previous_l
        else:
            rdex = previous_l

#[]


def lbracket():
    global inputprogram
    global bytecells
    global currentcell
    global currentchar
    if(bytecells[currentcell] > 0):
        currentchar += 1
    else:
        currentchar = inputprogram.find("]", currentchar) + 1

#]


def rbracket():
    global inputprogram
    global bytecells
    global currentcell
    global currentchar
    if(bytecells[currentcell] > 0):
        currentchar = find_matching_lbracket(currentchar)
    else:
        currentchar += 1

#.


def period():
    global bytecells
    global currentcell
    global currentchar
    global output
    output += chr(bytecells[currentcell])
    currentchar += 1

#,


def comma():
    global bytecells
    global currentcell
    global currentchar
    inpt = ""
    while(True):
        inpt = input("Input: ")
        if(len(inpt) != 1):
            logging.error("Input must be one byte!")
        else:
            break
    bytecells[currentcell] = ord(inpt)
    currentchar += 1

# prints various variables


def get_status():
    global inputprogram
    global currentchar
    global bytecells
    global currentcell
    if(inputprogram[currentchar] == '\n'):
        print("Current character", "\\n")
    else:
        print("Current character", inputprogram[currentchar])
    print("Current character index", currentchar)
    print("Byte Cells: ", bytecells)
    print("Current Cell: " + str(currentcell))
    print("\n")

# main

if __name__ == '__main__':
    if(verbose):
        get_status()
    validity_check()
    while(True):
        if(currentchar < (len(inputprogram) - 1)):
            atcurrentchar = inputprogram[currentchar]
            if(atcurrentchar == "+"):
                plus()
            elif(atcurrentchar == "-"):
                minus()
            elif(atcurrentchar == ">"):
                right()
            elif(atcurrentchar == "<"):
                left()
            elif(atcurrentchar == "["):
                lbracket()
            elif(atcurrentchar == "]"):
                rbracket()
            elif(atcurrentchar == "."):
                period()
            elif(atcurrentchar == ","):
                comma()
            elif(currentchar < (len(inputprogram) - 1)):
                currentchar += 1
            else:
                logging.info("Execution complete.")
                break
            if(verbose):
                get_status()
        else:
            break

    # get the output
    logging.info("Output: \n" + output)

    # close file
    f.close()
