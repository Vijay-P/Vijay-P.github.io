import random
from time import sleep

totaltile=19

nBrick = 3
nDesert = 1
nGrain = 4
nLumber = 4
nOre = 3
nWool = 4

row1=["","",""]
row2=["","","",""]
row3=["","","","",""]
row4=["","","",""]
row5=["","",""]

tokenlist=[2, 3, 3, 4, 4, 5, 5, 6, 6, 8, 8, 9, 9, 10, 10, 11, 11, 12]

currentType = ""

while(totaltile>0):
    while True:
        if totaltile>0:
            tiletype=random.randint(1,6)
            if(tiletype == 1):
                if nBrick <=0:
                    break
                else:
                    currentType = "B"
                    nBrick -= 1
                    totaltile -= 1

            elif(tiletype == 2):
                if nDesert <=0:
                    break
                else:
                    currentType = "D"
                    nDesert -= 1
                    totaltile -= 1

            elif(tiletype == 3):
                if nGrain <=0:
                    break
                else:
                    currentType = "G"
                    nGrain -= 1
                    totaltile -= 1

            elif(tiletype == 4):
                if nLumber <=0:
                    break
                else:
                    currentType = "L"
                    nLumber -= 1
                    totaltile -= 1

            elif(tiletype == 5):
                if nOre <=0:
                    break
                else:
                    currentType = "O"
                    nOre -= 1
                    totaltile -= 1

            elif(tiletype == 6):
                if nWool <=0:
                    break
                else:
                    currentType = "W"
                    nWool -= 1
                    totaltile -= 1

            if "" in row1:
                row1[row1.index("")]=currentType
            elif "" in row2:
                row2[row2.index("")]=currentType
            elif "" in row3:
                row3[row3.index("")]=currentType
            elif "" in row4:
                row4[row4.index("")]=currentType
            elif "" in row5:
                row5[row5.index("")]=currentType

            break

def insertat(row):
    global row1
    global row2
    global row3
    global row4
    global row5

    if row == 1 or row == 5:
        col = random.randint(0, 2)
        if row == 1:
            if row1[col] == "D":
                row1[col] += "-"
                return False
            elif len(row1[col])==1:
                row1[col]+=str(i)
                return True
            else:
                return False
        elif row == 5:
            if row5[col] == "D":
                row5[col] += "-"
                return False
            elif len(row5[col])==1:
                row5[col]+=str(i)
                return True
            else:
                return False
    elif row == 2 or row == 4:
        col = random.randint(0, 3)
        if row == 2:
            if row2[col] == "D":
                row2[col] += "-"
                return False
            elif len(row2[col])==1:
                row2[col]+=str(i)
                return True
            else:
                return False
        elif row == 4:
            if row4[col] == "D":
                row4[col] += "-"
                return False
            elif len(row4[col])==1:
                row4[col]+=str(i)
                return True
            else:
                return False
    elif row == 3:
        col = random.randint(0, 4)
        if row == 3:
            if row3[col] == "D":
                row3[col] += "-"
                return False
            elif len(row3[col])==1:
                row3[col]+=str(i)
                return True
            else:
                return False

for i in tokenlist:
    flag = False
    while flag == False:
        row = random.randint(1,5)
        flag = insertat(row)

print ' '.join(row1)+"\n"+' '.join(row2)+"\n"+' '.join(row3)+"\n"+ \
      ' '.join(row4)+"\n"+' '.join(row5)

totaltext = []
totaltext.append(row1)
totaltext.append(row2)
totaltext.append(row3)
totaltext.append(row4)
totaltext.append(row5)

def getText():
    return totaltext
