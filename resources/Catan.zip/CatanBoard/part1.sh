#!/bin/bash
identify brick.jpg
convert brick.jpg -alpha On brick.png
convert brick.png -shave 23x6 brick-crop.png
convert brick-crop.png -alpha extract brick-mask.png
convert brick-mask.png -fill black -draw "polygon 191,85 146,164 50,164 5,85 50,2 146,2" brick-mask-edges.png
convert brick-mask-edges.png -negate brick-mask-edges-neg.png
convert brick-crop.png brick-mask-edges-neg.png -alpha Off -compose CopyOpacity -composite brick-crop-transparent.png
