import randomText
from wand.display import display
from wand.image import Image

brick = Image(filename='brick-crop-transparent.png')
desert = Image(filename='desert-crop-transparent.png')
wool = Image(filename='wool-crop-transparent.png')
ore = Image(filename='ore-crop-transparent.png')
lumber = Image(filename='lumber-crop-transparent.png')
grain = Image(filename='grain-crop-transparent.png')
sea = Image(filename='sea-crop-transparent.png')
n = Image(filename='blank.png')
n2 = Image(filename='2.png')
n3 = Image(filename='3.png')
n4 = Image(filename='4.png')
n5 = Image(filename='5.png')
n6 = Image(filename='6.png')
n8 = Image(filename='8.png')
n9 = Image(filename='9.png')
n10 = Image(filename='10.png')
n11 = Image(filename='11.png')
n12 = Image(filename='12.png')

text=randomText.getText()

def convert(index, text):
    if index==0 or index==4:
        temp=[brick,brick,brick]
    elif index==1 or index == 3:
        temp=[brick,brick,brick,brick]
    else:
        temp=[brick,brick,brick,brick,brick]
    #
    z = int(len(text[index]))
    for x in reversed(range(z)):
        if "B" in text[index][x]:
            temp[z-x-1]=(brick)
        elif "D" in text[index][x]:
            temp[z-x-1]=(desert)
        elif "W" in text[index][x]:
            temp[z-x-1]=(wool)
        elif "O" in text[index][x]:
            temp[z-x-1]=(ore)
        elif "L" in text[index][x]:
            temp[z-x-1]=(lumber)
        elif "G" in text[index][x]:
            temp[z-x-1]=(grain)
        elif "S" in text[index][x]:
            temp[z-x-1]=(sea)
    #
    return temp

def convert2(index, text):
    if index==0 or index==4:
        temp=[n,n,n]
    elif index==1 or index == 3:
        temp=[n,n,n,n]
    else:
        temp=[n,n,n,n,n]
    #
    z = int(len(text[index]))
    for x in reversed(range(z)):
        if "2" in text[index][x] and "12" not in text[index][x]:
            temp[z-x-1]=(n2)
        elif "3" in text[index][x]:
            temp[z-x-1]=(n3)
        elif "4" in text[index][x]:
            temp[z-x-1]=(n4)
        elif "5" in text[index][x]:
            temp[z-x-1]=(n5)
        elif "6" in text[index][x]:
            temp[z-x-1]=(n6)
        elif "8" in text[index][x]:
            temp[z-x-1]=(n8)
        elif "9" in text[index][x]:
            temp[z-x-1]=(n9)
        elif "10" in text[index][x]:
            temp[z-x-1]=(n10)
        elif "11" in text[index][x]:
            temp[z-x-1]=(n11)
        elif "12" in text[index][x]:
            temp[z-x-1]=(n12)
    #
    return temp

#   tiles shift by 77 pixels downwards and 137 pixels right or left per attachment

def calculate(number, top, left, n):
    if left == True and number == False:
        return 400-(192/2)-(n*137)
    elif top == True and number == False:
        return n*77
    elif left == True and number == True:
        return 400-(192/2)-(n*137)+45
    elif top == True and number == True:
        return n*77+35

def compose(image):
    for x in text:
        temp = convert(text.index(x), text)
        temp2 = convert2(text.index(x), text)
        if text.index(x) == 0:
            #tiles
            image.composite(temp[0], left=calculate(False, False, True, 0), top=calculate(False, True, False, 0))
            image.composite(temp[1], left=calculate(False, False, True, 1), top=calculate(False, True, False, 1))
            image.composite(temp[2], left=calculate(False, False, True, 2), top=calculate(False, True, False, 2))
            #numbers
            image.composite(temp2[0], left=calculate(True, False, True, 0), top=calculate(True, True, False, 0))
            image.composite(temp2[1], left=calculate(True, False, True, 1), top=calculate(True, True, False, 1))
            image.composite(temp2[2], left=calculate(True, False, True, 2), top=calculate(True, True, False, 2))
        if text.index(x) == 1:
            #tiles
            image.composite(temp[0], left=calculate(False, False, True, -1), top=calculate(False, True, False, 1))
            image.composite(temp[1], left=calculate(False, False, True, 0), top=calculate(False, True, False, 2))
            image.composite(temp[2], left=calculate(False, False, True, 1), top=calculate(False, True, False, 3))
            image.composite(temp[3], left=calculate(False, False, True, 2), top=calculate(False, True, False, 4))
            #numbers
            image.composite(temp2[0], left=calculate(True, False, True, -1), top=calculate(True, True, False, 1))
            image.composite(temp2[1], left=calculate(True, False, True, 0), top=calculate(True, True, False, 2))
            image.composite(temp2[2], left=calculate(True, False, True, 1), top=calculate(True, True, False, 3))
            image.composite(temp2[3], left=calculate(True, False, True, 2), top=calculate(True, True, False, 4))
        if text.index(x) == 2:
            #tiles
            image.composite(temp[0], left=calculate(False, False, True, -2), top=calculate(False, True, False, 2))
            image.composite(temp[1], left=calculate(False, False, True, -1), top=calculate(False, True, False, 3))
            image.composite(temp[2], left=calculate(False, False, True, 0), top=calculate(False, True, False, 4))
            image.composite(temp[3], left=calculate(False, False, True, 1), top=calculate(False, True, False, 5))
            image.composite(temp[4], left=calculate(False, False, True, 2), top=calculate(False, True, False, 6))
            #numbers
            image.composite(temp2[0], left=calculate(True, False, True, -2), top=calculate(True, True, False, 2))
            image.composite(temp2[1], left=calculate(True, False, True, -1), top=calculate(True, True, False, 3))
            image.composite(temp2[2], left=calculate(True, False, True, 0), top=calculate(True, True, False, 4))
            image.composite(temp2[3], left=calculate(True, False, True, 1), top=calculate(True, True, False, 5))
            image.composite(temp2[4], left=calculate(True, False, True, 2), top=calculate(True, True, False, 6))
        if text.index(x) == 3:
            #tiles
            image.composite(temp[0], left=calculate(False, False, True, -2), top=calculate(False, True, False, 4))
            image.composite(temp[1], left=calculate(False, False, True, -1), top=calculate(False, True, False, 5))
            image.composite(temp[2], left=calculate(False, False, True, 0), top=calculate(False, True, False, 6))
            image.composite(temp[3], left=calculate(False, False, True, 1), top=calculate(False, True, False, 7))
            #numbers
            image.composite(temp2[0], left=calculate(True, False, True, -2), top=calculate(True, True, False, 4))
            image.composite(temp2[1], left=calculate(True, False, True, -1), top=calculate(True, True, False, 5))
            image.composite(temp2[2], left=calculate(True, False, True, 0), top=calculate(True, True, False, 6))
            image.composite(temp2[3], left=calculate(True, False, True, 1), top=calculate(True, True, False, 7))
        if text.index(x) == 4:
            #tiles
            image.composite(temp[0], calculate(False, False, True, -2), top=calculate(False, True, False, 6))
            image.composite(temp[1], left=calculate(False, False, True, -1), top=calculate(False, True, False, 7))
            image.composite(temp[2], left=calculate(False, False, True, 0), top=calculate(False, True, False, 8))
            #numbers
            image.composite(temp2[0], left=calculate(True, False, True, -2), top=calculate(True, True, False, 6))
            image.composite(temp2[1], left=calculate(True, False, True, -1), top=calculate(True, True, False, 7))
            image.composite(temp2[2], left=calculate(True, False, True, 0), top=calculate(True, True, False, 8))

with Image(width=800, height=790) as board:
    board.format = "png"
    compose(board)
    board.resize(400, 395)
    display(board)
    board.save(filename = "CatanBoard.png")
