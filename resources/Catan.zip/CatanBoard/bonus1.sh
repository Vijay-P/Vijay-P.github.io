#!/bin/bash
# Image cropper and transparency setter for SoC board
echo "JPG file cropper v1.0"
for var_name in $@
do
echo "File name is: $var_name"
var_name=$(echo $var_name | cut -f1 -d".")
echo "Identify:"
identify $var_name.jpg
echo "Converting file"
convert $var_name.jpg -alpha On $var_name.png
echo "Shaving image"
convert $var_name.png -shave 23x6 $var_name-crop.png
echo "Extracting image mask"
convert $var_name-crop.png -alpha extract $var_name-mask.png
echo "Masking image to polygon approximating tile"
convert $var_name-mask.png -fill black -draw "polygon 191,85 146,164 50,164 5,85 50,2 146,2" $var_name-mask-edges.png
echo "Making negative of mask"
convert $var_name-mask-edges.png -negate $var_name-mask-edges-neg.png
echo "Compositing mask"
convert $var_name-crop.png $var_name-mask-edges-neg.png -alpha Off -compose CopyOpacity -composite $var_name-crop-transparent.png
done
echo "Done!"
