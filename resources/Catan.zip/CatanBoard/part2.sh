#!/bin/bash
convert -size 100x100 xc:none blank.png
convert blank.png -stroke black  -fill white -strokewidth 2 -draw "circle 50,50 50,98" circle.png
convert circle.png -pointsize 50 -draw "text 25,70 '10'" 10.png
