#!/bin/bash
# SoC number token creator
echo "Token Creator v1.0"
convert -size 100x100 xc:none blank.png
convert blank.png -stroke black  -fill white -strokewidth 2 -draw "circle 50,50 50,98" circle.png
for num in 2 3 4 5 6 8 9 10 11 12
do
if [ $num == 6 -o $num == 8 ]
then
convert circle.png -fill red -pointsize 50 -draw "text 35,70 '$num'" $num.png
else
if [ $num -ge 10 ]
then
convert circle.png -pointsize 50 -draw "text 25,70 '$num'" $num.png
else
convert circle.png -pointsize 50 -draw "text 35,70 '$num'" $num.png
fi
fi
done
echo "Done!"
