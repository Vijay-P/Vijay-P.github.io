import Queue
import utils

'''
BFS that counts final path length
'''


def BFS_counting(grid, blocklist, heuristicfn):
    visited = []
    Q = Queue.Queue()
    Q.put((blocklist, 1))
    visited.append(blocklist)
    while not Q.empty():
        current_tuple = Q.get()
        current_list = current_tuple[0]
        current_length = current_tuple[1]
        for neighbor_list in utils.get_neighbors(utils.list_to_grid(grid, current_list), current_list):
            if (neighbor_list not in visited):
                visited.append(neighbor_list)
                Q.put((neighbor_list, current_length + 1))
                if(utils.is_goal(neighbor_list)):
                    print("GOAL")
                    print(current_length + 1)
                    print(neighbor_list)
                    utils.grid_printer(utils.list_to_grid(grid, neighbor_list))
                    return

'''
BFS that returns final state
'''


def BFS(grid, blocklist, heuristicfn):
    visited = []
    Q = Queue.Queue()
    Q.put(blocklist)
    visited.append(blocklist)
    while not Q.empty():
        current_list = Q.get()
        for neighbor_list in utils.get_neighbors(utils.list_to_grid(grid, current_list), current_list):
            if (neighbor_list not in visited):
                visited.append(neighbor_list)
                Q.put(neighbor_list)
                if(utils.is_goal(neighbor_list)):
                    print("GOAL")
                    print(neighbor_list)
                    utils.grid_printer(utils.list_to_grid(grid, neighbor_list))
                    return


'''
BFS that stores and returns final path
WARNING: BROKEN
'''


def BFS_path(grid, blocklist, heuristicfn):
    Q = Queue.Queue()
    Q.put([blocklist])
    while not Q.empty():
        current_path = Q.get()
        current_list = current_path[-1]
        for neighbor_list in utils.get_neighbors(utils.list_to_grid(grid, current_list), current_list):
            if (neighbor_list not in current_path):
                new_path = list(current_path)
                new_path.append(neighbor_list)
                Q.put(new_path)
                if(utils.is_goal(neighbor_list)):
                    print("SOLUTION")
                    for alist in new_path:
                        utils.grid_printer(utils.list_to_grid(grid, alist))
                    print(neighbor_list)
                    return


'''
A Star search that returns final state (not using past cost)
'''


def best_first(grid, blocklist, heuristicfn):
    visited = []
    Q = Queue.PriorityQueue()
    Q.put((heuristicfn(blocklist), blocklist))
    visited.append(blocklist)
    while not Q.empty():
        current_tuple = Q.get()
        current_list = current_tuple[1]
        for neighbor_list in utils.get_neighbors(utils.list_to_grid(grid, current_list), current_list):
            if (neighbor_list not in visited):
                visited.append(neighbor_list)
                Q.put((heuristicfn(neighbor_list), neighbor_list))
                if(utils.is_goal(neighbor_list)):
                    print("GOAL")
                    print(neighbor_list)
                    utils.grid_printer(utils.list_to_grid(grid, neighbor_list))
                    return

'''
A Star search that counts length of final path (not using past cost)
'''


def Astar_counting(grid, blocklist, heuristicfn):
    visited = []
    Q = Queue.PriorityQueue()
    Q.put((heuristicfn(blocklist), blocklist, 1))
    visited.append(blocklist)
    while not Q.empty():
        current_tuple = Q.get()
        current_list = current_tuple[1]
        length = current_tuple[2]
        for neighbor_list in utils.get_neighbors(utils.list_to_grid(grid, current_list), current_list):
            if (neighbor_list not in visited):
                visited.append(neighbor_list)
                Q.put((heuristicfn(neighbor_list), neighbor_list, length + 1))
                if(utils.is_goal(neighbor_list)):
                    print("GOAL")
                    print(length + 1)
                    print(neighbor_list)
                    utils.grid_printer(utils.list_to_grid(grid, neighbor_list))
                    return

'''
A Star search that returns final state (using past cost)
'''


def Astar(grid, blocklist, heuristicfn):
    visited = []
    Q = Queue.PriorityQueue()
    Q.put((heuristicfn(blocklist), blocklist, 1))
    visited.append(blocklist)
    while not Q.empty():
        current_tuple = Q.get()
        current_list = current_tuple[1]
        current_length = current_tuple[2]
        for neighbor_list in utils.get_neighbors(utils.list_to_grid(grid, current_list), current_list):
            if (neighbor_list not in visited):
                visited.append(neighbor_list)
                current_length += 1
                Q.put((current_length + heuristicfn(neighbor_list), neighbor_list, current_length))
                if(utils.is_goal(neighbor_list)):
                    print("GOAL")
                    print(neighbor_list)
                    utils.grid_printer(utils.list_to_grid(grid, neighbor_list))
                    return

'''
A Star search in proper, returns final path (using past cost)
WARNING: BROKEN
'''


def Astar_path(grid, blocklist, heuristicfn):
    Q = Queue.PriorityQueue()
    Q.put((1 + heuristicfn(blocklist), [blocklist]))
    while not Q.empty():
        current_tuple = Q.get()
        current_path = current_tuple[1]
        current_list = current_path[-1]
        for neighbor_list in utils.get_neighbors(utils.list_to_grid(grid, current_list), current_list):
            if (neighbor_list not in current_path):
                new_path = list(current_path)
                new_path.append(neighbor_list)
                Q.put((len(new_path) + heuristicfn(neighbor_list), new_path))
                if(utils.is_goal(neighbor_list)):
                    print("GOAL")
                    print(neighbor_list)
                    for block in new_path:
                        utils.grid_printer(utils.list_to_grid(grid, block))
                    return


'''
best_first search in proper, returns final path (not using past cost)
FUNCTIONAL PATHFINDING SOLUTION
'''


def best_first_path(grid, blocklist, heuristicfn):
    Q = Queue.PriorityQueue()
    Q.put((heuristicfn(blocklist), [blocklist]))
    # Q.put((heuristicd(grid, blocklist), [blocklist]))
    while not Q.empty():
        current_tuple = Q.get()
        current_path = current_tuple[1]
        current_list = current_path[-1]
        for neighbor_list in utils.get_neighbors(utils.list_to_grid(grid, current_list), current_list):
            if (neighbor_list not in current_path):
                new_path = list(current_path)
                new_path.append(neighbor_list)
                Q.put((heuristicfn(neighbor_list), new_path))
                # Q.put((heuristicd(utils.list_to_grid(grid, neighbor_list), blocklist), new_path))
                if(utils.is_goal(neighbor_list)):
                    print("GOAL")
                    print(neighbor_list)
                    for block in new_path:
                        utils.grid_printer(utils.list_to_grid(grid, block))
                    return
