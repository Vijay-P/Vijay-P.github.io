import searchAlgorithms
import string
import utils
import time

'''
UNBLOCK ME:

A puzzle where you have a walled 6x6 grid of tiles.
Tiles can only move along their lenthwise axis.
There is a hole in the wall.
The goal is to get the red tile access to the hole.
'''

'''
heuristic: 1 + 1 for every block between red brick and exit
'''


def heuristic(blocklist):
    count = 1
    for [instance, coordlist] in blocklist:
        if(instance != 'Z'):
            for coords in coordlist:
                if (coords[0] == 3):
                    count += 1
                    break
    return count

'''
heuristic: 1 + 1 for every block between red brick and exit + 1 for every those bricks of length 3
'''


def heuristicb(blocklist):
    overall = 0
    count = 1
    for [instance, coordlist] in blocklist:
        if(instance != 'Z'):
            length = 0
            for coords in coordlist:
                length += 1
                if (coords[0] == 3):
                    count += 1
                    break
            if(length >= 3):
                overall += 1
    return count + overall

'''
heuristic: 1 + 1 for every block between red brick and exit + 1 for every space between red block and exit
'''


def heuristicc(blocklist):
    count = 1
    for [instance, coordlist] in blocklist:
        if(instance == 'Z'):
            lastcoord = coordlist[-1]
            last = lastcoord[1]
            spaces_between = 6 - last
    for [instance, coordlist] in blocklist:
        if(instance != 'Z'):
            for coords in coordlist:
                if (coords[0] == 3):
                    count += 1
                    break
    return count + spaces_between

'''
heuristic: 1 + 1 for every block between red brick and exit + 1 for every space between red block and exit + 1 if those blocks are immobilized
'''


def heuristicd(grid, blocklist):
    count = 1
    for [instance, coordlist] in blocklist:
        if(instance == 'Z'):
            lastcoord = coordlist[-1]
            last = lastcoord[1]
            spaces_between = 6 - last
    for [instance, coordlist] in blocklist:
        if(instance != 'Z'):
            if(utils.move_up(grid, instance, blocklist) == None or utils.move_down(grid, instance, blocklist) == None):
                count += 1
            for coords in coordlist:
                if (coords[0] == 3):
                    count += 1
                    break
    return count + spaces_between


def solvePuzzle(algorithm, heuristic, grid, blocks):
    algorithm(heuristic)


def evaluateHeuristics(algorithm_list, heuristic_list, grid, blocks):
    verbose = True
    total_tests = len(heuristic_list) * len(algorithm_list)
    test_num = 1
    times_list = []
    for algorithm in algorithm_list:
        for heuristic in heuristic_list:
            times = []
            start_time = time.time()
            if verbose:
                print("Test number %d/%d" % (test_num, total_tests))
                test_num += 1
            solvePuzzle(algorithm, heuristic, grid, blocks)
            times.append(-1)  # figure out timing information
            end_time = time.time()
            total_time = end_time - start_time
            times_list.append(total_time)
    return times_list


def slidingTester(grid, blocks):
    algorithm_list = []
    # algorithm = lambda (heuristicfn): searchAlgorithms.BFS(grid, blocks, heuristicfn)
    # algorithm_list.append(algorithm)
    # algorithm = lambda (heuristicfn): searchAlgorithms.Astar(grid, blocks, heuristicfn)
    # algorithm_list.append(algorithm)
    # algorithm = lambda (heuristicfn): searchAlgorithms.best_first(grid, blocks, heuristicfn)
    # algorithm_list.append(algorithm)
    algorithm = lambda (heuristicfn): searchAlgorithms.best_first_path(grid, blocks, heuristicfn)
    algorithm_list.append(algorithm)

    heuristic_list = []
    heuristic = lambda (blocklist): heuristic(blocklist)
    heuristic_list.append(heuristic)
    # heuristic = lambda (blocklist): heuristicb(blocklist)
    # heuristic_list.append(heuristic)
    heuristic = lambda (blocklist): heuristicc(blocklist)
    heuristic_list.append(heuristic)
    heuristic = lambda (blocklist): heuristicd(grid, blocklist)
    heuristic_list.append(heuristic)

    times_list = evaluateHeuristics(algorithm_list, heuristic_list, grid, blocks)

    for i, time in enumerate(times_list):
        print("Trial %i: %.2f seconds" % (i, time))

if __name__ == "__main__":
    # puzzle.txt is the first easy level in the game
    # puzzle3.txt is an easier version of the first puzzle
    # puzzle2.txt is the last hard level in the game
    filename = "puzzle.txt"
    f = open(filename)
    grid = []
    letters = []
    for line in f:
        grid.append([])
        for character in line:
            if (character != '\n'):
                grid[-1].append(character)
            if (character in string.ascii_uppercase and character not in letters):
                letters.append(character)
    utils.grid_printer(grid)
    blocks = utils.get_blocks(grid, letters)
    print(blocks)
    slidingTester(grid, blocks)
    # BFS(grid, blocks)
    # # BFS_path(grid, blocks)
    # # BFS_counting(grid, blocks)
    # Astar(grid, blocks)
    # # Astar_counting(grid, blocks)
    # best_first(grid, blocks)
    # # Astar_path(grid, blocks)
    # best_first_path(grid, blocks)
