import string

'''
converts a list encoding into a grid
'''


def list_to_grid(grid, blocklist):
    newgrid = list(grid)
    for line in range(len(grid)):
        for character in range(len(grid[line])):
            if (grid[line][character] in string.ascii_uppercase):
                newgrid[line][character] = '*'
    for [instance, coordlist] in blocklist:
        for coord in coordlist:
            newgrid[coord[0]][coord[1]] = str(instance)
    return(newgrid)

'''
prints a given grid in a legible format
'''


def grid_printer(grid):
    for line in grid:
        linestring = ""
        for character in line:
            linestring += character
            linestring += " "
        print(linestring)

'''
returns blocks in a grid given the letters in the grid
'''


def get_blocks(grid, letters):
    shapes = []
    for x in range(len(letters)):
        current_shape = []
        y = letters[x]
        for line in range(len(grid)):
            l = grid[line]
            for character in range(len(l)):
                c = grid[line][character]
                if (c == y):
                    current_shape.append([line, character])
        shapes.append([y, current_shape])
    return(shapes)

'''
returns true if the block is oriented horizontally. returns false if the block is oriented vetically
'''


def is_horizontal(block_coords):
    xcoordlist = []
    ycoordlist = []
    for coord in block_coords:
        if coord[0] not in xcoordlist:
            xcoordlist.append(coord[0])
        if coord[1] not in ycoordlist:
            ycoordlist.append(coord[1])
    if len(ycoordlist) == 1:
        return False
    elif len(xcoordlist) == 1:
        return True
    else:
        return None

'''
moves a given block right, returns a list encoding
'''


def move_right(grid, block, blocklist):
    block_coords = []
    for [instance, coordlist] in blocklist:
        if instance == block:
            block_coords = list(coordlist)
    block_coords2 = []
    if(is_horizontal(block_coords)):
        next_coordinate = [block_coords[-1][0], block_coords[-1][1] + 1]
        if(grid[next_coordinate[0]][next_coordinate[1]] not in string.ascii_uppercase and grid[next_coordinate[0]][next_coordinate[1]] not in ['+', '-', '|']):
            for [x, y] in block_coords:
                block_coords2.append([x, y + 1])
            new_entry = [block, block_coords2]
            blocklist2 = list(blocklist)
            for entry in range(len(blocklist2)):
                [x, y] = blocklist2[entry]
                if x == block:
                    blocklist2[entry] = new_entry
                    return blocklist2

'''
moves a given block left, returns a list encoding
'''


def move_left(grid, block, blocklist):
    block_coords = []
    for [instance, coordlist] in blocklist:
        if instance == block:
            block_coords = list(coordlist)
    block_coords2 = []
    if(is_horizontal(block_coords)):
        next_coordinate = [block_coords[0][0], block_coords[0][1] - 1]
        if(grid[next_coordinate[0]][next_coordinate[1]] not in string.ascii_uppercase and grid[next_coordinate[0]][next_coordinate[1]] not in ['+', '-', '|']):
            for [x, y] in block_coords:
                block_coords2.append([x, y - 1])
            new_entry = [block, block_coords2]
            blocklist2 = list(blocklist)
            for entry in range(len(blocklist2)):
                [x, y] = blocklist2[entry]
                if x == block:
                    blocklist2[entry] = new_entry
                    return blocklist2

'''
moves a given block up, returns a list encoding
'''


def move_up(grid, block, blocklist):
    block_coords = []
    for [instance, coordlist] in blocklist:
        if instance == block:
            block_coords = list(coordlist)
    block_coords2 = []
    if(not is_horizontal(block_coords)):
        next_coordinate = [block_coords[0][0] - 1, block_coords[0][1]]
        if(grid[next_coordinate[0]][next_coordinate[1]] not in string.ascii_uppercase and grid[next_coordinate[0]][next_coordinate[1]] not in ['+', '-', '|']):
            for [x, y] in block_coords:
                block_coords2.append([x - 1, y])
            new_entry = [block, block_coords2]
            blocklist2 = list(blocklist)
            for entry in range(len(blocklist2)):
                [x, y] = blocklist2[entry]
                if x == block:
                    blocklist2[entry] = new_entry
                    return blocklist2

'''
moves a given block down, returns a list encoding
'''


def move_down(grid, block, blocklist):
    block_coords = []
    for [instance, coordlist] in blocklist:
        if instance == block:
            block_coords = list(coordlist)
    block_coords2 = []
    if(not is_horizontal(block_coords)):
        next_coordinate = [block_coords[-1][0] + 1, block_coords[-1][1]]
        if(grid[next_coordinate[0]][next_coordinate[1]] not in string.ascii_uppercase and grid[next_coordinate[0]][next_coordinate[1]] not in ['+', '-', '|']):
            for [x, y] in block_coords:
                block_coords2.append([x + 1, y])
            new_entry = [block, block_coords2]
            blocklist2 = list(blocklist)
            for entry in range(len(blocklist2)):
                [x, y] = blocklist2[entry]
                if x == block:
                    blocklist2[entry] = new_entry
                    return blocklist2

'''
for a given state encoding, returns a list of all possible adjacent states (or moves)
'''


def get_neighbors(grid, blocklist):
    neighbors = []
    for [instance, coordlist] in blocklist:
        if(is_horizontal(coordlist)):
            left = move_left(grid, instance, blocklist)
            right = move_right(grid, instance, blocklist)
            if(left != None):
                neighbors.append(left)
            if(right != None):
                neighbors.append(right)
        else:
            up = move_up(grid, instance, blocklist)
            down = move_down(grid, instance, blocklist)
            if(up != None):
                neighbors.append(up)
            if(down != None):
                neighbors.append(down)
    return neighbors

'''
returns true if red brick is at the exit or if no bricks obstruct red brick's path to exit
'''


def is_goal(blocklist):
    no_others = True
    for [instance, coordlist] in blocklist:
        if(instance == 'Z'):
            if [3, 6] in coordlist:
                return True
        if(instance != 'Z'):
            for coords in coordlist:
                if (coords[0] == 3):
                    no_others = False
    if(no_others == True):
        return True
    else:
        return False
