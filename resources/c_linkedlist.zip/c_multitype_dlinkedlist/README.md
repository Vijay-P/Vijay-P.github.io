# c_multitype_dlinkedlist

### Doubly Linked List in C, int and multitype versions
- `dlinkedlist_int.c` is a doubly linked list for integers

- `dlinkedlist_tunion.c` is a doubly linked list that uses a tagged union to accept multiple types

- Compiled with `gcc -Wall -ansi -pedantic -Werror`

- `dllint_tester.c` tests doubly linked list for integers

- `dlltunion_tester.c` tests doubly linked list for multiple types

**This project is avaliable through git via:**
- SSH: git@src-code.simons-rock.edu:vpillai13/c_multitype_dlinkedlist.git
- HTTPS: https://src-code.simons-rock.edu/git/vpillai13/c_multitype_dlinkedlist.git
