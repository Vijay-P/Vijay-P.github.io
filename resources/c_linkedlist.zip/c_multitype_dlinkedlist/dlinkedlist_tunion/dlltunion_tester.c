#include "dlinkedlist_tunion.c"

int testint()
{
	union mtype temp;
	struct node* list;
	struct node* mynode;

	temp.i = 5;
	list = new_ll(INT, temp);
	printf("Create test: %s\n", (char*)tostring(list));
	temp.i = 4;
	append_node(list, temp);
	printf("Append test: %s\n", (char*)tostring(list));
	temp.i = 3;
	append_node(list, temp);
	printf("Append test: %s\n", (char*)tostring(list));
	remove_node(list, 1);
	printf("Remove index 1: %s\n", (char*)tostring(list));
	mynode = get_node(list, 1);
	printf("Get index 1 and print value: %d\n", mynode->value.i);
	printf("Get value at 1: %d\n", get_value(list, 1).i);
	delete_ll(list);
	printf("Linked list deleted.\n");

	return 0;
}


int testdouble()
{
	union mtype temp;
	struct node* list;
	struct node* mynode;

	temp.d = 5.2;
	list = new_ll(DOUBLE, temp);
	printf("Create test: %s\n", (char*)tostring(list));
	temp.d = 4.39;
	append_node(list, temp);
	printf("Append test: %s\n", (char*)tostring(list));
	temp.d = 3.2222;
	append_node(list, temp);
	printf("Append test: %s\n", (char*)tostring(list));
	remove_node(list, 1);
	printf("Remove index 1: %s\n", (char*)tostring(list));
	mynode = get_node(list, 1);
	printf("Get index 1 and print value: %f\n", mynode->value.d);
	printf("Get value at 1: %f\n", get_value(list, 1).d);
	delete_ll(list);
	printf("Linked list deleted.\n");

	return 0;
}

int testfloat()
{
	union mtype temp;
	struct node* list;
	struct node* mynode;

	temp.f = 5.2;
	list = new_ll(DOUBLE, temp);
	printf("Create test: %s\n", (char*)tostring(list));
	temp.f = 4.39;
	append_node(list, temp);
	printf("Append test: %s\n", (char*)tostring(list));
	temp.f = 3.2222;
	append_node(list, temp);
	printf("Append test: %s\n", (char*)tostring(list));
	remove_node(list, 1);
	printf("Remove index 1: %s\n", (char*)tostring(list));
	mynode = get_node(list, 1);
	printf("Get index 1 and print value: %f\n", mynode->value.f);
	printf("Get value at 1: %f\n", get_value(list, 1).f);
	delete_ll(list);
	printf("Linked list deleted.\n");

	return 0;
}

int testchar()
{
	union mtype temp;
	struct node* list;
	struct node* mynode;

	temp.c = 'a';
	list = new_ll(CHAR, temp);
	printf("Create test: %s\n", (char*)tostring(list));
	temp.c = 'a';
	append_node(list, temp);
	printf("Append test: %s\n", (char*)tostring(list));
	temp.c = 'b';
	append_node(list, temp);
	printf("Append test: %s\n", (char*)tostring(list));
	remove_node(list, 1);
	printf("Remove index 1: %s\n", (char*)tostring(list));
	mynode = get_node(list, 1);
	printf("Get index 1 and print value: %c\n", mynode->value.c);
	printf("Get value at 1: %c\n", get_value(list, 1).c);
	delete_ll(list);
	printf("Linked list deleted.\n");

	return 0;
}

int teststring()
{
	union mtype temp;
	struct node* list;
	struct node* mynode;

	temp.s = "oh";
	list = new_ll(STRING, temp);
	printf("Create test: %s\n", (char*)tostring(list));
	temp.s = "my";
	append_node(list, temp);
	printf("Append test: %s\n", (char*)tostring(list));
	temp.s = "god";
	append_node(list, temp);
	printf("Append test: %s\n", (char*)tostring(list));
	remove_node(list, 1);
	printf("Remove index 1: %s\n", (char*)tostring(list));
	mynode = get_node(list, 1);
	printf("Get index 1 and print value: %s\n", mynode->value.s);
	printf("Get value at 1: %s\n", get_value(list, 1).s);
	delete_ll(list);
	printf("Linked list deleted.\n");

	return 0;
}


int main()
{
	int ret;

	if ((ret = testint()) != 0)
		return ret;
	else if ((ret = testfloat()) != 0)
		return ret;
	else if ((ret = testdouble()) != 0)
		return ret;
	else if ((ret = testchar()) != 0)
		return ret;
	else
		return teststring();

}
