#include <stdlib.h>
#include <stdio.h>
#include <string.h>

/*
   structure for a basic node
   next: pointer to next node
   value: value of node
   last: pointer to last node
 */
struct node {
	struct node* next;
	int value;
	struct node* last;
};

/*
   create a new linked list
   value: value of first node
 */
struct node* new_ll(int value)
{
	struct node* head;

	head = (struct node*)malloc(sizeof(struct node));

	head->value = value;
	return head;
}

/*
   add a node to a given linked list
   head: head node of linked list
   value: value for new node
 */
struct node* append_node(struct node* head, int value)
{
	struct node* current;
	struct node* new;

	if (head == NULL) {
		fprintf(stderr, "Error: Head node does not exist! Exiting.\n");
		exit(-1);
	}

	current = head;

	new = (struct node*)malloc(sizeof(struct node));

	while (current->next != NULL)
		current = current->next;

	current->next = new;
	new->last = current;
	new->value = value;
	return new;
}

/*
   returns node at index
   head: head node of linked list
   index: index of node you want to get
 */
struct node* get_node(struct node* head, int index)
{
	struct node* current;
	int i;

	if (head == NULL) {
		fprintf(stderr, "Error: Head node does not exist! Exiting.\n");
		exit(-1);
	}

	i = 0;
	current = head;

	for (i = 0; i < index; i++) {
		if (current->next == NULL) {
			fprintf(stderr, " Error: Index out of bounds! Exiting.\n");
			exit(-1);
		}
		current = current->next;
	}

	return current;
}

/*
   returns value at given index
   head: head node of linked list
   index: index of node whose value you want
 */
int get_value(struct node* head, int index)
{
	struct node* current;

	current = get_node(head, index);

	return current->value;
}

/*
   remove given node from the linked list
   head: head node of linked list
   index: index of node to remove
 */
void remove_node(struct node* head, int index)
{
	struct node* current;

	current = get_node(head, index);

	current->last->next = current->next;
	current->next->last = current->last;
	free(current);
}

/*
   free linked list from memory
   head: head node of linked list
 */
void delete_ll(struct node* head)
{
	struct node* next;

	next = head->next;
	while (next->next != NULL) {
		free(head);
		head = next;
		next = head->next;

	}

}

/*
   get string describing linked list
   head: head node of linked list
 */
char* tostring(struct node* head)
{
	char * out;
	char * temp;
	char comma[3] = { ',', ' ', '\0' };
	struct node* current;

	if (head == NULL) {
		fprintf(stderr, "Error: Head node does not exist! Exiting.\n");
		exit(-1);
	}

	out = (char*)malloc(1);
	temp = (char*)malloc(1);
	current = head;
	sprintf(out, "%d", current->value);

	while (current->next != NULL) {
		current = current->next;

		temp = (char*)realloc(temp, 1 + current->value / 10);
		sprintf(temp, "%d", current->value);

		out = (char*)realloc(out, strlen(out) + strlen(temp) + 2);
		strcat(out, comma);
		strcat(out, temp);
	}

	return out;

}
