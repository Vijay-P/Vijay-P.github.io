#include "dlinkedlist_int.c"
int main()
{
	struct node* list;
	struct node* mynode;

	list = new_ll(5);
	printf("Create test: %s\n", (char*)tostring(list));
	append_node(list, 4);
	printf("Append test: %s\n", (char*)tostring(list));
	append_node(list, 3);
	printf("Append test: %s\n", (char*)tostring(list));
	remove_node(list, 1);
	printf("Remove index 1: %s\n", (char*)tostring(list));
	mynode = get_node(list, 1);
	printf("Get index 1 and print value: %d\n", mynode->value);
	printf("Get value at 1: %d\n", get_value(list, 1));
	delete_ll(list);
	printf("Linked list deleted.\n");
	return 0;
}
