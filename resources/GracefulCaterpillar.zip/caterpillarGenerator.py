import networkx as nx
import random
import math

from netxutils.draw import drawGraph
from netxutils.draw import saveDrawing, showDrawing

'''
Uses the parametric form of the equation of a circle to generate coordinates for points.
Input: list(leaf vertices), int(x coodinate of spine)
Output: list(coodinates for leaves)
'''


def PointsInCircum(pointlist, centerx):
    if(pointlist == None):
        return None
    # list of coordinates that we will return
    coordlist = []
    # angle for arcs if dividing circle evenly, offset by 45 degrees to prevent overlap
    arcdeg = (360 / len(pointlist)) - 45
    # convert to radians
    arc = math.radians(arcdeg)
    # radius of the circle
    r = float(.5)
    # variable we will be using for angle
    theta = arc
    # center of the circle (y=0 for all spine vertices)
    x1 = centerx
    y1 = 0
    # for each point, use equation to generate coordinate pair
    for point in range(len(pointlist)):
        print(math.degrees(theta))
        x = x1 + r * math.cos(theta)
        y = y1 + r * math.sin(theta)
        # increase angle by arc, adjust for initial offset
        theta += arc + math.radians(45)
        # add to coordinate list
        coordlist.append((x, y))
    return coordlist

'''
Randomly generate a caterpillar.
Parameters: int(maximum possible number of spines), int(multiplier for number of leaves)
Output: nx.Graph(Graph object), dict(position dictionary)
'''


def random_caterpillar(maxspine=12, multiplier=6):
    # pick a random number between two and given maximum
    number_spines = random.randint(2, maxspine)
    # pick a random number between 1 and maximum*multiplier
    number_leaves = random.randint(1, multiplier * number_spines)

    # instantiate a graph object
    G = nx.Graph()

    # create a sequential list from 0 to the chosen number of spines, apply to graph as nodes
    spine_list = list(range(0, number_spines))
    G.add_nodes_from(spine_list, Spine=True)
    # mark these nodes as spine nodes
    for v in G.nodes():
        G.node[v]['spine'] = True
    # make a list of these nodes (somewhat redundant)
    spine_vertices = [v for v in G.nodes() if G.node[v]['spine']]
    # position all of these nodes at their value on the y=0 axis
    pos = {x: (x, 0) for x in spine_vertices}
    # for each spine vertex, make an edge to the adjacent spine, and label the edge as a spine edge.
    for spine_vertex in range(len(spine_vertices)):
        if (spine_vertex != len(spine_vertices) - 1):
            spine = spine_vertices[spine_vertex]
            adjacent_spine = spine_vertices[spine_vertex + 1]
            G.add_edge(spine, adjacent_spine)
            G.edge[spine][adjacent_spine]['spine'] = True

    # dictionary of spines (key) to connected leaves(value)
    spine_dictionary = {}
    # create a sequential list from 0 to the chosen number of spines, apply to graph as nodes
    leaf_list = list(range(number_spines,  number_spines + (number_leaves)))
    G.add_nodes_from(leaf_list, Spine=False)
    # mark these nodes as non-spine nodes
    for v in leaf_list:
        G.node[v]['spine'] = False
    # make a list fo these nodes (somewhat redundant)
    leaf_vertices = [v for v in G.nodes() if not G.node[v]['spine']]
    # for each leaf vertex, randomly assign it to a spine node in the spine_dictionary
    for leaf_vertex in range(len(leaf_vertices)):
        leaf = leaf_vertices[leaf_vertex]
        leafspine = random.randint(0, number_spines - 1)
        if (not spine_dictionary.has_key(leafspine)):
            spine_dictionary[leafspine] = [leaf]
        else:
            spine_dictionary[leafspine].append(leaf)
    # for each spine vertex, take the leaves and get the positions for them.
    # Add these positions to the pos dictionary.
    for spine_vertex in range(len(spine_vertices)):
        spine = spine_vertices[spine_vertex]
        leaves = spine_dictionary.get(spine)
        points = PointsInCircum(leaves, spine_vertex)
        if(points != None):
            for leaf in range(len(leaves)):
                pos[leaves[leaf]] = points[leaf]
    # for each leaf vertex, make an edge between it and it's spine vertex, label
    # the edge  as a non-spine edge
    for leaf_vertex in range(len(leaf_vertices)):
        leaf = leaf_vertices[leaf_vertex]
        leafspine = 0
        for key in spine_dictionary:
            if(leaf in spine_dictionary.get(key)):
                leafspine = key
        G.add_edge(leaf, leafspine)
        G.edge[leaf][leafspine]['spine'] = False

    # return the graph and the position dictionary
    return(G, pos)

if __name__ == '__main__':
    random_caterpillar()
