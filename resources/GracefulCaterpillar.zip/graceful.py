import networkx as nx
import random
import math

from netxutils.draw import saveDrawing, showDrawing
from caterpillarGenerator import random_caterpillar

'''
Draws the graph and labels it.
'''


def draw_graph_and_labels(G, pos, labelsv, labelse):
    size = 25
    nx.draw_networkx(G, pos, with_labels=False, node_size=1200, width=5, font_size=20)
    nx.draw_networkx_labels(G, pos, labelsv, node_size=1200, font_size=size)
    nx.draw_networkx_edge_labels(G, pos, labelse, font_size=size)
    saveDrawing("test.png")
    showDrawing()

'''
Returns leaf vertices that are neighbors of a given spine vertex.
'''


def neighbor_leaves(G, c):
    neighbors = []
    leaf_edges = [(u, v) for (u, v) in G.edges() if not G.edge[u][v]['spine']]
    for edge in leaf_edges:
        if (edge[0] == c):
            neighbors.append(edge[1])
        elif (edge[1] == c):
            neighbors.append(edge[0])
    return neighbors

'''
Wrapper function for adding to dictionary.
'''


def label(dic, key, label):
    dic[key] = label
    return dic

'''
Algorithm for generating a graceful labeling.
'''


def make_graceful(G):
    all_vertices = [v for v in G.nodes()]
    spine_vertices = [v for v in G.nodes() if G.node[v]['spine']]

    edge_labels = {}
    vertex_labels = {}

    top = len(all_vertices) - 1
    bottom = 0

    for g in range(0, len(spine_vertices)):
        if (g % 2 != 0):
            vertex_labels = label(vertex_labels, spine_vertices[g], bottom)
            bottom += 1
            neighbors = neighbor_leaves(G, spine_vertices[g])
            if(not neighbors == None):
                for neighbor in neighbors:
                    vertex_labels = label(vertex_labels, neighbor, top)
                    top -= 1
                    edge_labels = label(edge_labels, (spine_vertices[g], neighbor), abs(
                        vertex_labels.get(spine_vertices[g]) - vertex_labels.get(neighbor)))
        else:
            vertex_labels = label(vertex_labels, spine_vertices[g], top)
            top -= 1
            neighbors = neighbor_leaves(G, spine_vertices[g])
            if(not neighbors == None):
                for neighbor in neighbors:
                    vertex_labels = label(vertex_labels, neighbor, bottom)
                    bottom += 1
                    edge_labels = label(edge_labels, (spine_vertices[g], neighbor), abs(
                        vertex_labels.get(spine_vertices[g]) - vertex_labels.get(neighbor)))
        if(g != 0):
            edge_labels = label(
                edge_labels, (spine_vertices[g], spine_vertices[g - 1]), abs(vertex_labels.get(spine_vertices[g]) - vertex_labels.get(spine_vertices[g - 1])))

    return vertex_labels, edge_labels

'''
Main
'''

if __name__ == '__main__':
    G, pos = random_caterpillar(6)
    vertices, edges = make_graceful(G)
    draw_graph_and_labels(G, pos, vertices, edges)
